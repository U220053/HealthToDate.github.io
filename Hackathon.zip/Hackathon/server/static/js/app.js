console.log("Saptarshi Nandi");

res = document.getElementById('result')
button = document.getElementById('btn2')

button.addEventListener('click', ()=>{
    res.innerHTML = ""
})
